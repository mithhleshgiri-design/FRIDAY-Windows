$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

if (!(Test-Path ".venv")) {
  py -3.11 -m venv .venv
}
& .\.venv\Scripts\python.exe -m pip install --upgrade pip
& .\.venv\Scripts\pip.exe install -e . pyinstaller

if (!(Test-Path ".env") -and (Test-Path ".env.example")) {
  Copy-Item ".env.example" ".env"
  Write-Host "Created .env from .env.example. Add your API keys before running."
}

$collect = @(
  "--clean", "--noconfirm", "--onedir",
  "--paths", ".",
  "--collect-all", "fastmcp",
  "--collect-all", "mcp",
  "--collect-all", "livekit",
  "--collect-all", "livekit.agents",
  "--collect-all", "livekit.plugins.google",
  "--collect-all", "livekit.plugins.sarvam",
  "--collect-all", "livekit.plugins.openai",
  "--collect-all", "livekit.plugins.silero",
  "--hidden-import", "server",
  "--hidden-import", "agent_friday",
  "--hidden-import", "friday",
  "--hidden-import", "friday.tools",
  "--hidden-import", "friday.prompts",
  "--hidden-import", "friday.resources"
)

& .\.venv\Scripts\pyinstaller.exe @collect --name FridayServer server.py
if ($LASTEXITCODE -ne 0) { throw "FridayServer build failed." }

& .\.venv\Scripts\pyinstaller.exe @collect --name FridayVoice agent_friday.py
if ($LASTEXITCODE -ne 0) { throw "FridayVoice build failed." }

& .\.venv\Scripts\pyinstaller.exe --clean --noconfirm --onedir --paths . --name StartFriday start_friday.py
if ($LASTEXITCODE -ne 0) { throw "StartFriday build failed." }

if (Test-Path "release") { Remove-Item "release" -Recurse -Force }
New-Item -ItemType Directory -Force -Path "release" | Out-Null
Copy-Item "dist\FridayServer" "release\FridayServer" -Recurse -Force
Copy-Item "dist\FridayVoice" "release\FridayVoice" -Recurse -Force
Copy-Item "dist\StartFriday\*" "release\" -Recurse -Force
Copy-Item ".env.example" "release\.env.example" -Force

Write-Host ""
Write-Host "Build complete:"
Write-Host "  release\StartFriday.exe"
Write-Host "  release\FridayServer\FridayServer.exe"
Write-Host "  release\FridayVoice\FridayVoice.exe"
