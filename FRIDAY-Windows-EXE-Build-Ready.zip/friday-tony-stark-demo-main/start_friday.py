"""
FRIDAY Windows launcher.
Starts the local MCP server and LiveKit voice agent.
"""
from __future__ import annotations
import os, time, subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent if not getattr(__import__("sys"), "frozen", False) else Path(__import__("sys").executable).resolve().parent
SERVER = ROOT / "FridayServer" / "FridayServer.exe"
VOICE = ROOT / "FridayVoice" / "FridayVoice.exe"

def main():
    if not SERVER.exists() or not VOICE.exists():
        raise SystemExit(
            "FRIDAY files are incomplete. Expected:\n"
            f"  {SERVER}\n  {VOICE}"
        )
    env = os.environ.copy()
    server = subprocess.Popen([str(SERVER)], cwd=str(SERVER.parent), env=env)
    voice = None
    try:
        time.sleep(2)
        voice = subprocess.Popen([str(VOICE)], cwd=str(VOICE.parent), env=env)
        print("FRIDAY started. Press Ctrl+C to stop.")
        voice.wait()
    except KeyboardInterrupt:
        pass
    finally:
        for p in (voice, server):
            if p and p.poll() is None:
                try:
                    p.terminate()
                except Exception:
                    pass

if __name__ == "__main__":
    main()
